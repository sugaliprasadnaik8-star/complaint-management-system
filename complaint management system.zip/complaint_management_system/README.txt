RESOLVENOW — COMPLAINT MANAGEMENT SYSTEM

Founder: S. Naik

HOW TO RUN
1. Extract the ZIP file.
2. Open the complaint_management_system folder.
3. Double-click index.html, or open the folder in VS Code and use Live Server.
4. Use the navigation menu to visit Home, About, Submit, Track, Dashboard, Founder, and Contact.

FEATURES
- Responsive multi-page website.
- Complaint form with validation and generated reference ID.
- Track complaint by reference ID and view status history.
- Dashboard with status/category filters and search.
- Update complaint status (Submitted, In Progress, Resolved, Rejected).
- Export complaint records as CSV.
- Contact form demo storage.
- Founder page includes the supplied founder image.

IMPORTANT
This is a front-end academic demonstration. Complaints and contact messages are stored in the browser's localStorage. They are not sent to a server and will not automatically appear on another device/browser. The dashboard has no authentication and must not be used for real confidential complaint data. A real deployment needs a secure backend, database, login/role permissions, validation, backups, and privacy/security controls.
